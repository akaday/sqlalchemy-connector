# SQL Connector

SQL Connector is a Python package that allows you to connect to any SQL database that you can otherwise connect to with Python.

## Installation

```bash
pip install sql_connector
